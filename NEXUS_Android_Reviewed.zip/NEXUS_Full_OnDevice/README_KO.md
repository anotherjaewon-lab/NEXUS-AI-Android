# NEXUS AI Android — 개선판 소스 프로젝트

> **이 ZIP은 APK가 아니라 Android Studio에서 빌드하는 소스 프로젝트입니다.** 아래 검증 상태와 한계를 반드시 확인하세요.

## 개선·검토 반영

- LiteRT-LM Android 의존성 및 CPU 온디바이스 엔진 초기화 코드
- Engine/Conversation 접근을 전용 단일 스레드 dispatcher로 제한
- 모델 가져오기 중 임시 파일(`.partial`)을 사용하고 실패 시 정리
- 모델 파일 0바이트 확인 및 교체 오류 처리
- 모델 로드 중/응답 중 중복 실행 방지
- 초기화 실패 시 임시 Engine 정리
- 빈 응답 오류 시 빈 NEXUS 말풍선 제거
- 대화 기록 JSON 로컬 저장 (최대 500개 메시지 항목)
- 연구 노트 로컬 저장/삭제 (최대 300개), 답변을 노트로 보관
- 연구 노트와 대화 기록을 앱 데이터에 보관하며 Android 백업 제외
- INTERNET 권한 제거: 앱 자체 네트워크 권한 없음
- Compose UI: 대화/연구노트 탭, 모델 복사/로드 상태, 전제 비판·가설 생성 단축 프롬프트
- GitHub Actions APK 빌드 workflow 포함
- Java 17 컴파일 설정 및 `.gitignore`

## Android Studio에서 APK 만들기

1. Android Studio 최신 안정 버전을 설치합니다.
2. 이 프로젝트 폴더를 `Open` 합니다.
3. Android SDK Platform 35와 JDK 17 이상을 설치합니다.
4. Gradle Sync가 완료될 때까지 기다립니다.
5. `Build > Build APK(s)`를 실행합니다.
6. `app/build/outputs/apk/debug/app-debug.apk`를 휴대폰에 설치합니다.
7. 앱에서 호환 `.litertlm` 모델 파일을 선택하고 **AI 로드**를 누릅니다.

### GitHub Actions로 빌드

프로젝트를 GitHub 저장소의 `main` 또는 `master` 브랜치에 올리면 workflow가 실행됩니다. 또는 Actions에서 **Build NEXUS Android APK**를 수동 실행하세요. 완료된 workflow의 Artifacts에서 `NEXUS-debug-apk`를 내려받을 수 있습니다.

## 모델 관련

- 모델은 APK에 포함하지 않습니다. 용량, 배포 라이선스, 기기별 메모리 차이 때문입니다.
- 반드시 LiteRT-LM 호환 `.litertlm` 모델을 사용하세요. 일반 GGUF 파일은 그대로 사용할 수 없습니다.
- 처음에는 작은 모델로 기기 메모리/속도/발열을 확인하세요. CPU backend는 호환성이 우선이며 GPU/NPU 가속을 보장하지 않습니다.
- 첫 모델 파일 선택/다운로드는 사용자가 별도로 준비해야 합니다. 앱은 모델을 자동 다운로드하지 않습니다.

## 개인정보 및 저장

- 앱에는 INTERNET 권한이 없습니다. 앱 기능은 로컬 파일과 로컬 추론을 전제로 합니다.
- 대화/노트는 앱 내부 SharedPreferences에 저장되고 Android 자동 백업에서 제외됩니다.
- 앱 삭제 또는 Android 앱 데이터 삭제 시 기록과 모델 파일이 삭제됩니다.
- 모델 파일은 `filesDir/model.litertlm`에 저장됩니다.

## 현재 미구현 / 검증 한계

- 이 환경에서는 Android SDK/Gradle 실행 환경이 없어 APK 컴파일, 설치, 실기기 테스트를 수행하지 못했습니다. 따라서 **컴파일 성공 또는 기기 작동을 보장하지 않습니다.**
- 모델별 LiteRT-LM 호환성, 실제 메모리 사용량, 추론 속도/발열은 휴대폰에서 검증해야 합니다.
- 현재 연구노트는 사용자가 답변을 저장하는 수동 기록입니다. 가설·실험·관측·판정의 구조화 DB, 자동 실험 실행, 모델 재학습, 코드 자기수정/자율 능력 향상은 구현되어 있지 않습니다.
- 모델 답변은 생성 결과이며 검증된 사실이 아닙니다. 중요한 결론은 외부 출처 또는 실제 실험으로 확인해야 합니다.

## 기술 구성

- Kotlin / Jetpack Compose / Android ViewModel
- LiteRT-LM Android `0.18.0`
- Android Gradle Plugin `8.9.1`, Kotlin `2.1.10`
- `minSdk 24`, `targetSdk 35`, Java 17
