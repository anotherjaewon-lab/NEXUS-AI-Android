package com.nexus.full

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NexusApp(filesDir.absolutePath, cacheDir.absolutePath) } }
    }
}

@Composable
fun NexusApp(filesPath: String, cachePath: String, vm: NexusVM = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }
    val modelFile = remember(filesPath) { File(filesPath, "model.litertlm") }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri, filesPath)
    }

    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Text("AI") }, label = { Text("대화") })
            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Text("노트") }, label = { Text("연구 기록") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEXUS AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("독립형 연구 보조 • On-device", style = MaterialTheme.typography.bodyMedium)
                }
                Surface(color = if (state.ready) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.small) {
                    Text(if (state.ready) "로컬 실행" else "모델 대기", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium)
                }
            }
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(state.status, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(enabled = !state.importing && !state.loading, onClick = { pickModel.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) {
                            Text(if (state.importing) "복사 중…" else "모델 선택")
                        }
                        Button(enabled = modelFile.exists() && !state.loading && !state.importing, onClick = { vm.load(modelFile.absolutePath, cachePath) }, modifier = Modifier.weight(1f)) {
                            Text(if (state.loading) "로드 중…" else "AI 로드")
                        }
                    }
                    if (state.loading || state.importing) LinearProgressIndicator(Modifier.fillMaxWidth())
                    state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
            if (selectedTab == 0) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = state.ready && !state.busy && input.isNotBlank(), onClick = {
                        vm.send("다음 주제의 숨은 전제, 정의, 분류 기준, 반례를 분석해줘: ${input.trim()}"); input = ""
                    }, modifier = Modifier.weight(1f)) { Text("전제 비판") }
                    OutlinedButton(enabled = state.ready && !state.busy && input.isNotBlank(), onClick = {
                        vm.send("주제: ${input.trim()}\n경쟁 가설 5개, 각 가설의 검증 가능한 예측과 반증 실험을 제안해줘."); input = ""
                    }, modifier = Modifier.weight(1f)) { Text("가설 생성") }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (state.messages.isEmpty()) item {
                        Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("NEXUS 연구 공간", fontWeight = FontWeight.Bold)
                            Text("모델을 로드한 뒤 질문을 입력하세요. 사실·전제·가설·불확실성을 구분하도록 설계된 연구 보조입니다.")
                        } }
                    }
                    items(state.messages) { message ->
                        Card(colors = CardDefaults.cardColors(containerColor = if (message.first == "사용자") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(message.first, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Text(message.second)
                            }
                        }
                    }
                }
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("연구 질문 / 생각") }, minLines = 1, maxLines = 4)
                Button(enabled = state.ready && !state.busy && input.isNotBlank(), onClick = { vm.send(input); input = "" }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (state.busy) "응답 생성 중…" else "NEXUS에 질문")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(enabled = state.messages.any { it.first == "NEXUS" && it.second.isNotBlank() }, onClick = {
                        val answer = state.messages.lastOrNull { it.first == "NEXUS" && it.second.isNotBlank() }?.second.orEmpty()
                        vm.saveResearch("NEXUS 답변 기록", answer)
                    }) { Text("마지막 답변 연구 기록") }
                    TextButton(onClick = { vm.clearHistory() }) { Text("대화 삭제") }
                }
            } else {
                Text("연구 노트는 이 기기에 저장됩니다. 답변을 검증된 사실로 간주하지 말고 출처와 실험으로 확인하세요.", style = MaterialTheme.typography.bodySmall)
                if (state.notes.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("저장된 연구 기록이 없습니다.") }
                } else {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(state.notes) { note ->
                            Card {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(note.title, fontWeight = FontWeight.Bold)
                                    Text(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date(note.createdAt)), style = MaterialTheme.typography.labelSmall)
                                    Text(note.body)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        TextButton(onClick = { vm.deleteResearch(note) }) { Text("삭제") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Text("대화와 노트는 기기 내부 저장 • 서버 전송 없음", style = MaterialTheme.typography.labelSmall)
        }
    }
}
