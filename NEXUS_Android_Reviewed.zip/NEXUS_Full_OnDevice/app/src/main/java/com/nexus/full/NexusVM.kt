package com.nexus.full

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

private const val MAX_CHAT_ITEMS = 500
private const val MAX_RESEARCH_ITEMS = 300

data class ResearchNote(val title: String, val body: String, val createdAt: Long)
data class NexusState(
    val status: String = "모델 파일(.litertlm)을 선택한 뒤 AI 로드를 누르세요.",
    val loading: Boolean = false,
    val importing: Boolean = false,
    val ready: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val messages: List<Pair<String, String>> = emptyList(),
    val notes: List<ResearchNote> = emptyList()
)

class NexusVM(app: Application) : AndroidViewModel(app) {
    // LiteRT-LM Engine/Conversation are confined to this single-thread dispatcher.
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "nexus-llm").apply { isDaemon = true } }
    private val engineDispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + engineDispatcher)
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private val prefs = app.getSharedPreferences("nexus_local", 0)

    private fun restoreMessages(): List<Pair<String, String>> = runCatching {
        val arr = JSONArray(prefs.getString("messages", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            o.getString("role") to o.getString("text")
        }.takeLast(MAX_CHAT_ITEMS)
    }.getOrDefault(emptyList())

    private fun restoreNotes(): List<ResearchNote> = runCatching {
        val arr = JSONArray(prefs.getString("research_notes", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ResearchNote(o.optString("title", "연구 기록"), o.optString("body"), o.optLong("createdAt"))
        }.takeLast(MAX_RESEARCH_ITEMS).reversed()
    }.getOrDefault(emptyList())

    private fun persistMessages(list: List<Pair<String, String>>) {
        val arr = JSONArray()
        list.takeLast(MAX_CHAT_ITEMS).forEach { (role, text) ->
            arr.put(JSONObject().put("role", role).put("text", text))
        }
        prefs.edit().putString("messages", arr.toString()).apply()
    }

    private fun persistNotes(list: List<ResearchNote>) {
        val arr = JSONArray()
        list.take(MAX_RESEARCH_ITEMS).forEach { n ->
            arr.put(JSONObject().put("title", n.title).put("body", n.body).put("createdAt", n.createdAt))
        }
        prefs.edit().putString("research_notes", arr.toString()).apply()
    }

    private val _state = MutableStateFlow(NexusState(messages = restoreMessages(), notes = restoreNotes()))
    val state: StateFlow<NexusState> = _state.asStateFlow()

    fun setError(message: String) { _state.update { it.copy(error = message) } }

    fun clearHistory() {
        _state.update { it.copy(messages = emptyList(), error = null) }
        persistMessages(emptyList())
    }

    fun saveResearch(title: String, body: String) {
        if (body.isBlank()) return
        val note = ResearchNote(title.trim().ifBlank { "연구 기록" }, body.trim(), System.currentTimeMillis())
        val updated = (listOf(note) + _state.value.notes).take(MAX_RESEARCH_ITEMS)
        _state.update { it.copy(notes = updated) }
        persistNotes(updated)
    }

    fun deleteResearch(note: ResearchNote) {
        val updated = _state.value.notes.filterNot { it.createdAt == note.createdAt && it.body == note.body }
        _state.update { it.copy(notes = updated) }
        persistNotes(updated)
    }

    fun importModel(uri: Uri, directory: String) {
        if (_state.value.importing || _state.value.loading) return
        scope.launch(Dispatchers.IO) {
            _state.update { it.copy(importing = true, error = null, status = "모델 파일을 앱 내부로 복사 중…") }
            val target = File(directory, "model.litertlm")
            val temp = File(directory, "model.litertlm.partial")
            try {
                getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "선택한 파일을 읽을 수 없습니다." }
                    temp.outputStream().buffered().use { output -> input.copyTo(output, 1024 * 1024) }
                }
                require(temp.length() > 0) { "선택한 파일이 비어 있습니다." }
                val backup = File(directory, "model.litertlm.previous")
                if (backup.exists()) backup.delete()
                val hadTarget = target.exists()
                if (hadTarget) check(target.renameTo(backup)) { "기존 모델을 안전하게 보관하지 못했습니다." }
                if (!temp.renameTo(target)) {
                    if (hadTarget) backup.renameTo(target)
                    throw IllegalStateException("모델 파일을 최종 위치로 이동하지 못했습니다.")
                }
                backup.delete()
                _state.update { it.copy(status = "모델 복사 완료 (${target.length() / 1024 / 1024} MB). AI 로드를 누르세요.", error = null) }
            } catch (e: Exception) {
                temp.delete()
                _state.update { it.copy(error = e.localizedMessage ?: "모델 복사 실패", status = "모델 가져오기 실패") }
            } finally {
                _state.update { it.copy(importing = false) }
            }
        }
    }

    fun load(path: String, cache: String) {
        if (_state.value.loading || _state.value.busy) return
        scope.launch {
            _state.update { it.copy(loading = true, ready = false, error = null, status = "모델 초기화 중… (수십 초~수 분 걸릴 수 있음)") }
            var candidate: Engine? = null
            try {
                val file = File(path)
                require(file.exists() && file.isFile && file.length() > 0) { "model.litertlm 파일이 없습니다. 먼저 모델을 선택하세요." }
                closeModel()
                val builtEngine = Engine(EngineConfig(modelPath = file.absolutePath, backend = Backend.CPU(), cacheDir = cache))
                candidate = builtEngine
                builtEngine.initialize()
                val newConversation = builtEngine.createConversation(ConversationConfig(systemInstruction = Contents.of(
                    """You are NEXUS, a critical and recursive research assistant. Respond in Korean by default.
                    Separate facts, assumptions, hypotheses, and unknowns. Question definitions, categories,
                    hidden premises, and inference rules. Propose competing explanations, falsifiable predictions,
                    counterexamples, and practical tests. State uncertainty and limitations. Do not present generated
                    hypotheses as verified facts or claim autonomous learning/retraining that did not occur.""".trimIndent()
                )))
                engine = candidate
                conversation = newConversation
                candidate = null
                _state.update { it.copy(ready = true, loading = false, status = "온디바이스 모델 실행 중 • CPU backend", error = null) }
            } catch (e: Exception) {
                runCatching { candidate?.close() }
                _state.update { it.copy(loading = false, ready = false, status = "모델 초기화 실패", error = e.localizedMessage ?: e.javaClass.simpleName) }
            }
        }
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || !_state.value.ready || _state.value.busy) return
        scope.launch {
            val start = (_state.value.messages + ("사용자" to clean) + ("NEXUS" to "")).takeLast(MAX_CHAT_ITEMS)
            _state.update { it.copy(busy = true, error = null, messages = start) }
            persistMessages(start)
            try {
                val activeConversation = checkNotNull(conversation) { "대화 엔진이 준비되지 않았습니다." }
                activeConversation.sendMessageAsync(clean).collect { chunk ->
                    val current = _state.value.messages
                    if (current.isNotEmpty() && current.last().first == "NEXUS") {
                        val updated = current.dropLast(1) + ("NEXUS" to (current.last().second + chunk.toString()))
                        _state.update { it.copy(messages = updated) }
                        persistMessages(updated)
                    }
                }
            } catch (e: Exception) {
                val current = _state.value.messages
                val cleaned = if (current.lastOrNull()?.first == "NEXUS" && current.last().second.isBlank()) current.dropLast(1) else current
                _state.update { it.copy(messages = cleaned, error = "응답 생성 실패: ${e.localizedMessage ?: e.javaClass.simpleName}") }
                persistMessages(cleaned)
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    private fun closeModel() {
        runCatching { conversation?.close() }
        conversation = null
        runCatching { engine?.close() }
        engine = null
    }

    override fun onCleared() {
        // Close native resources on their owning thread before shutting it down.
        scope.launch { closeModel() }.invokeOnCompletion {
            engineDispatcher.close()
            executor.shutdown()
        }
    }
}
